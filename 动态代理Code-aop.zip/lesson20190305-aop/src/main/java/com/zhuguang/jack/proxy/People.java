package com.zhuguang.jack.proxy;

public interface People {

    public void zhaoduixiang();
}
