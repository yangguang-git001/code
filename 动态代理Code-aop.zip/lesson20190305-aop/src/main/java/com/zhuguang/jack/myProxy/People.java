package com.zhuguang.jack.myProxy;

public interface People {

    public void zhaoduixiang() throws Throwable;
}
